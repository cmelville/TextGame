package com.cmm.textgame.main;

import com.cmm.textgame.objects.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;

import static java.lang.System.in;

/**
 * Created by Chris on 9/26/2016.
 */
public class TestClass {
    public static void main(String[] args) {
//        Player player = Launcher.player;
//        player.setBalSkill(50);
//        Map<String, Function<Integer,null>> skillMap = new HashMap<String, Function<Integer,Integer>>(){{
//            //put("bal",player.getBalSkill());
//            put("bal",event -> {int i = 50; return player.setIntSkill(50)});
//        }};
//
//        Scanner scan = new Scanner(in);
//        System.out.println(skillMap.get(scan.next()));



        long start = System.currentTimeMillis();

        for(int i = 1; i<5000; i++){
            System.out.println("Stuff");
        }

        long end = System.currentTimeMillis();
        System.out.println(end-start);
    }
}