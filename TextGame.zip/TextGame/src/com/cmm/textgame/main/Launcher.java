package com.cmm.textgame.main; /**
 * Created by Chris on 9/11/2016.
 */

import com.cmm.textgame.objects.Player;
import com.cmm.textgame.view.MainMenuView;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;

public class Launcher extends Application {
    public static Player player = new Player();
    public static Stage stage;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Launcher.stage = primaryStage;

        new MainMenuView(stage);
    }
}
