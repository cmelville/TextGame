package com.cmm.textgame.objects;

/**
 * Created by Chris on 9/16/2016.
 */
public class Armor extends Item{
    private int armorValue;

    public Armor(String name, String contextName, String description, int price, int weight, String specialRules, int armorValue) {
        super(name, contextName, description, price, weight, specialRules);
        this.armorValue = armorValue;
    }

    @Override
    public String importantStats(){
        return "Armor Value: "+armorValue;
    }

    public void useItem(Player player){
        if(player.getEquippedArmor() == null){
            player.setEquippedArmor(this);
            player.getInventory().remove(this);
        }else{
            player.getInventory().remove(this);
            player.getInventory().add(player.getEquippedArmor());
            player.setEquippedArmor(this);
            player.getInventory().remove(this);
        }
    }
}
