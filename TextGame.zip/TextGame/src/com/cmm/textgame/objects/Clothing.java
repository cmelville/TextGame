package com.cmm.textgame.objects;

/**
 * Created by Chris on 9/16/2016.
 */
public class Clothing extends Item{
    public Clothing(String name, String contextName, String description, int price, int weight, String specialRules) {
        super(name, contextName, description, price, weight, specialRules);
    }
    public void useItem(Player player){
        if(player.getClothing() == null){
            player.setClothing(this);
            player.getInventory().remove(this);
        }else{
            player.getInventory().remove(this);
            player.getInventory().add(player.getClothing());
            player.setClothing(this);
        }
    }

    @Override
    public String importantStats() {
        return null;
    }
}
