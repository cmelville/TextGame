package com.cmm.textgame.objects;

/**
 * Created by Chris on 9/16/2016.
 */
public class RangedWeapon extends Weapon{
    private int clipSize;
    private String fireRate;

    public RangedWeapon(String name, String contextName, String description, int price, int weight, String specialRules, int damMin, int damMax, int pen, int clipSize, String fireRate) {
        super(name, contextName, description, price, weight, specialRules, damMin, damMax, pen);
        this.clipSize = clipSize;
        this.fireRate = fireRate;
    }

    @Override
    public void useItem(Player player) {
        if(player.getEquippedRangedWeapon() == null){
            player.setEquippedRangedWeapon(this);
            player.removeItemFromInventory(this);
        }else{
            player.removeItemFromInventory(this);
            player.addItemToInventory(player.getEquippedRangedWeapon());
            player.setEquippedRangedWeapon(this);
        }
    }

    @Override
    public String importantStats() {
        return super.importantStats()+"\nClip: "+clipSize+"\t\tROF: "+fireRate;
    }
}
