package com.cmm.textgame.objects;

import com.cmm.textgame.controller.PrimarySceneController;

import java.util.ArrayList;

/**
 * Created by Chris on 9/14/2016.
 */
public class Player {
    private String name;
    private String gender; //If positive then male, negative female

    //location
    private String generalLocation;
    private String specificLocation;

    //basic skills used for tests
    private int balSkill;
    private int wepSkill;
    private int strSkill;
    private int endSkill;
    private int agSkill;
    private int intSkill;
    private int chaSkill;

    //used for under the hood calculations like melee damage bonus/damage negated and carry weight
    //anytime something is added, update the parse function to include it if necessary!
    private int balModifier;
    private int wepModifier;
    private int strModifier;
    private int endModifier;
    private int agModifier;
    private int intModifier;
    private int chaModifier;
    private boolean canDodge = true;
    private int armorValue;

    //can be added/taken away with perks and equipment, ex a gun that gives +10 to bal
    private int balSkillBonus;
    private int wepSkillBonus;
    private int strSkillBonus;
    private int endSkillBonus;
    private int agSkillBonus;
    private int intSkillBonus;
    private int chaSkillBonus;

    //health related variables
    private int maxHealth;
    private int currentHealth;
    private double healthBarPercentage;

    //level related variables
    private int level;
    private int currentXP;
    private int xpToNextLevel=20;
    private double xpBarPercentage;
    private int skillPointsLeft;
    private int skillPointsSpent;

    //appearance related variables
    private String race;
    private String age;
    private String bodyTrait;
    private String bodyTrait2;
    private String hairStyle;
    private String hairColor;
    private String eyeColor;
    private String complexion;
    private String lineage;
    private String facialHair;

    private boolean hasWings = false;
    private String wingType = null;

    private Clothing headGear = null;
    private Clothing clothing = null;

    //Inventory
    private ArrayList<InventoryItem> inventory = new ArrayList<>();
    private Weapon equippedRangedWeapon = null;
    private Weapon equippedMeleeWeapon = null;
    private Armor equippedArmor = null;
    private int credits;
    private int maxInventoryWeight;
    private int inventoryWeight;

    //Relations
    private int charlotteRep = 0;


    private String time;
    private int daysPassed = 0;


    public int calculateCurrentInventoryWeight(){
        int totalWeight = 0;
        for(int i =0;i<inventory.size();i++){
            totalWeight += inventory.get(i).getWeight();
        }
        if(equippedRangedWeapon!=null){
            totalWeight += equippedRangedWeapon.getWeight();
        }
        if(equippedMeleeWeapon!=null){
            totalWeight += equippedMeleeWeapon.getWeight();
        }
        if(equippedArmor!=null){
            totalWeight += equippedArmor.getWeight();
        }
        inventoryWeight = totalWeight;
        return totalWeight;
    }

    public boolean hasRoomInInventory(InventoryItem item){
        return (inventoryWeight+item.getWeight())<=maxInventoryWeight;
    }

    public void calculateMaxHealth(){
        /**
         * Finds and sets the players max health, used during character creation or leveling up
         */
        this.maxHealth = endModifier*4;
    }

    public double calculateHealthBarPercentage(){
        /**
         * Calculates the percentage of the health bar and returns it as a width from
         * between 0 and 175 (the width of the bar)
         */
        double doubleMaxHealth = maxHealth;
        double doubleCurrentHealth = currentHealth;
        healthBarPercentage = 175*(doubleCurrentHealth/doubleMaxHealth);
        return healthBarPercentage;
    }

    public double calculateXpBarPercentage(){
        /**
         * Calculates the percentage of the XP bar and returns it as a width from
         * between 0 and 175 (the width of the bar)
         */
        double doubleXpToNextLevel = xpToNextLevel;
        double doubleCurrentXP = currentXP;
        xpBarPercentage = 175*(doubleCurrentXP/doubleXpToNextLevel);
        return xpBarPercentage;
    }

    public void calculateModifiers(){
        /**
         * Finds the players modifiers, used during character creation or leveling up.
         */
        this.balModifier = balSkill/10;
        this.wepModifier = wepSkill/10;
        this.strModifier = strSkill/10;
        this.endModifier = endSkill/10;
        this.agModifier = agSkill/10;
        this.intModifier = intSkill/10;
        this.chaModifier = chaSkill/10;
        this.maxInventoryWeight = strModifier * 4; //not an actual weight, arbitrary unit to denote inventory size (bigger objects consume more)
        //(idea) player can hold up to 2x their maxInventoryWeight however loose the ability to dodge if they do.
    }

    //Call when adding an item
    public void parseSpecialRules(InventoryItem item){
        if(item.getSpecialRules()!=null) {
            String[] ruleList = item.getSpecialRules().split(",");

            for (int i = 0; i < ruleList.length; i++) {
                String[] ruleListParts = ruleList[i].split("=");

                String variable = ruleListParts[0];
                String action = ruleListParts[1];

                if (variable.equals("b")) {
                    balSkillBonus += Integer.parseInt(action);
                } else if (variable.equals("w")) {
                    wepSkillBonus += Integer.parseInt(action);
                } else if (variable.equals("s")) {
                    strSkillBonus += Integer.parseInt(action);
                } else if (variable.equals("e")) {
                    endSkillBonus += Integer.parseInt(action);
                } else if (variable.equals("a")) {
                    agSkillBonus += Integer.parseInt(action);
                } else if (variable.equals("i")) {
                    intSkillBonus += Integer.parseInt(action);
                } else if (variable.equals("c")) {
                    chaSkillBonus += Integer.parseInt(action);
                } else if (variable.equals("canDodge")) {
                    if (action.equals("t")) {
                        canDodge = true;
                    } else {
                        canDodge = false;
                    }
                }
            }
        }
    }

    //Call when removing an item
    public void parseInverseSpecialRules(InventoryItem item){
        if(item.getSpecialRules()!=null) {
            String[] ruleList = item.getSpecialRules().split(",");

            for (int i = 0; i < ruleList.length; i++) {
                String[] ruleListParts = ruleList[i].split("=");

                String variable = ruleListParts[0];
                String action = ruleListParts[1];

                if (variable.equals("b")) {
                    balSkillBonus -= Integer.parseInt(action);
                } else if (variable.equals("w")) {
                    wepSkillBonus -= Integer.parseInt(action);
                } else if (variable.equals("s")) {
                    strSkillBonus -= Integer.parseInt(action);
                } else if (variable.equals("e")) {
                    endSkillBonus -= Integer.parseInt(action);
                } else if (variable.equals("a")) {
                    agSkillBonus -= Integer.parseInt(action);
                } else if (variable.equals("i")) {
                    intSkillBonus -= Integer.parseInt(action);
                } else if (variable.equals("c")) {
                    chaSkillBonus -= Integer.parseInt(action);
                } else if (variable.equals("canDodge")) {
                    if (action.equals("f")) {
                        canDodge = true;
                    } else {
                        canDodge = false;
                    }
                }
            }
        }
    }

    public void addItemToInventory(InventoryItem item){
        parseSpecialRules(item);
        inventory.add(item);
        calculateCurrentInventoryWeight();
    }

    public void removeItemFromInventory(InventoryItem item){
        parseInverseSpecialRules(item);
        inventory.remove(item);
        calculateCurrentInventoryWeight();
    }



    /**
     * ###################################
     * #### ACTIONS THE PLAYER CAN DO ####
     * ###################################
     */

    public void gainExperience(int experience){
        if(currentXP + experience<=xpToNextLevel){
            currentXP += experience;
        }else{
            level+=1;
            skillPointsLeft += intModifier*1.5;
            currentXP += experience;
            currentXP -= xpToNextLevel;
            double doubleLevel = level;
            xpToNextLevel = 50 * (int) Math.pow(doubleLevel,2.6);
        }
    }

    public void passTime(String addedTime){
        String[] splitAddedTime = addedTime.split(":");
        String[] splitOldTime = time.split(":");
        splitOldTime[1] = ""+(Integer.parseInt(splitOldTime[1])+Integer.parseInt(splitAddedTime[1]));
        if(Integer.parseInt(splitOldTime[1])>=60){
            splitOldTime[0] = ""+(Integer.parseInt(splitOldTime[0])+1);
            splitOldTime[1] = ""+(Integer.parseInt(splitOldTime[1])-60);
            if(Integer.parseInt(splitOldTime[1])<10){
                splitOldTime[1] = "0"+splitOldTime[1];
            }
        }
        splitOldTime[0] = ""+(Integer.parseInt(splitOldTime[0])+Integer.parseInt(splitAddedTime[0]));
        if(Integer.parseInt(splitOldTime[0])>=24){
            daysPassed+=1;
            splitOldTime[0] = ""+(Integer.parseInt(splitOldTime[0])-24);
        }
        String newTime = splitOldTime[0]+":"+splitOldTime[1];
        time = newTime;
    }

    public void gainCredits(int amount){
        credits += amount;
    }

    public boolean canAfford(Item item){
        if(item.getPrice()<credits){
            return true;
        }else{
            return false;
        }
    }

    public String describePlayer(){
        String description = "" +
                "You're a "+gender+" "+race+" who comes from a family of "+lineage+".\n" +
                "At first glance you would be described as "+age+", "+bodyTrait+", and "+bodyTrait2+"." +
                " Your "+hairStyle+" "+hairColor+" hair compliments your "+eyeColor+" eyes and "+complexion+" skin. ";
        if(facialHair != null){
            description = description + " In addition, your face is adorned by a "+facialHair+". ";
        }
        if(hasWings){
            description = description + "\n\nOn your back rest a large pair of "+wingType+" wings.";
        }
        description = description +"\n\nYou're currently wearing "+clothing.getContextName()+" ";
        if(headGear != null){
            description = description +"and sporting a "+headGear.getContextName()+". ";
        }else{
            description = description +". ";
        }
        if(equippedArmor != null){
            description = description +" Over your clothing you have equipped "+equippedArmor.getContextName()+" and ";
            if(equippedRangedWeapon != null){
                description = description +"are wielding "+equippedRangedWeapon.getContextName();
                if(equippedMeleeWeapon != null){
                    description = description + " and "+equippedMeleeWeapon.getContextName()+".";
                }else{
                    description = description + ".";
                }
            }else if(equippedMeleeWeapon != null) {
                description = description +"are wielding "+equippedMeleeWeapon.getContextName()+".";
            }else{
                description = description +"currently have no weapons equipped.";
            }
        }else if(equippedRangedWeapon != null){
            description = description +"You're wielding "+equippedRangedWeapon.getContextName();
            if(equippedMeleeWeapon != null){
                description = description + " and "+equippedMeleeWeapon.getContextName()+".";
            }else{
                description = description + ".";
            }
        }else if(equippedMeleeWeapon != null) {
            description = description +"You're wielding "+equippedMeleeWeapon.getContextName()+".";
        }else{
            description = description +"You have no weapons equipped.";
        }
        return description;
    }

    public void takeDamage(int damage){
        this.currentHealth = currentHealth - damage;
    }

    /**
     * ##############################
     * #### GETTERS AND SETTERS #####
     * ##############################
     */

    //Name and Gender
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    //Location


    public String getGeneralLocation() {
        return generalLocation;
    }

    public void setGeneralLocation(String generalLocation) {
        this.generalLocation = generalLocation;
    }

    public String getSpecificLocation() {
        return specificLocation;
    }

    public void setSpecificLocation(String specificLocation) {
        this.specificLocation = specificLocation;
    }

    //Skills
    public int getBalSkill() {
        return balSkill + balSkillBonus;
    }

    public void setBalSkill(int balSkill) {
        this.balSkill = balSkill;
    }

    public int getWepSkill() {
        return wepSkill + wepSkillBonus;
    }

    public void setWepSkill(int wepSkill) {
        this.wepSkill = wepSkill;
    }

    public int getStrSkill() {
        return strSkill + strSkillBonus;
    }

    public void setStrSkill(int strSkill) {
        this.strSkill = strSkill;
    }

    public int getEndSkill() {
        return endSkill + endSkillBonus;
    }

    public void setEndSkill(int endSkill) {
        this.endSkill = endSkill;
    }

    public int getAgSkill() {
        return agSkill + endSkillBonus;
    }

    public void setAgSkill(int agSkill) {
        this.agSkill = agSkill;
    }

    public int getIntSkill() {
        return intSkill + endSkillBonus;
    }

    public void setIntSkill(int intSkill) {
        this.intSkill = intSkill;
    }

    public int getChaSkill() {
        return chaSkill + chaSkillBonus;
    }

    public void setChaSkill(int chaSkill) {
        this.chaSkill = chaSkill;
    }

    //Modifier
    public int getBalModifier() {
        return balModifier;
    }

    public void setBalModifier(int balModifier) {
        this.balModifier = balModifier;
    }

    public int getWepModifier() {
        return wepModifier;
    }

    public void setWepModifier(int wepModifier) {
        this.wepModifier = wepModifier;
    }

    public int getStrModifier() {
        return strModifier;
    }

    public void setStrModifier(int strModifier) {
        this.strModifier = strModifier;
    }

    public int getEndModifier() {
        return endModifier;
    }

    public void setEndModifier(int endModifier) {
        this.endModifier = endModifier;
    }

    public int getAgModifier() {
        return agModifier;
    }

    public void setAgModifier(int agModifier) {
        this.agModifier = agModifier;
    }

    public int getIntModifier() {
        return intModifier;
    }

    public void setIntModifier(int intModifier) {
        this.intModifier = intModifier;
    }

    public int getChaModifier() {
        return chaModifier;
    }

    public void setChaModifier(int chaModifier) {
        this.chaModifier = chaModifier;
    }

    public int getArmorValue() {
        return armorValue;
    }

    public void setArmorValue(int armorValue) {
        this.armorValue = armorValue;
    }

    public boolean isCanDodge() {
        return canDodge;
    }

    public void setCanDodge(boolean canDodge) {
        this.canDodge = canDodge;
    }

    //Health
    public int getMaxHealth() {
        return maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
    }

    public int getCurrentHealth() {
        return currentHealth;
    }

    public void setCurrentHealth(int currentHealth) {
        this.currentHealth = currentHealth;
    }

    //level and XP

    public int getSkillPointsLeft() {
        return skillPointsLeft;
    }

    public void setSkillPointsLeft(int skillPointsLeft) {
        this.skillPointsLeft = skillPointsLeft;
    }

    public int getSkillPointsSpent() {
        return skillPointsSpent;
    }

    public void setSkillPointsSpent(int skillPointsSpent) {
        this.skillPointsSpent = skillPointsSpent;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getCurrentXP() {
        return currentXP;
    }

    public void setCurrentXP(int currentXP) {
        this.currentXP = currentXP;
    }

    public int getXpToNextLevel() {
        return xpToNextLevel;
    }

    public void setXpToNextLevel(int xpToNextLevel) {
        this.xpToNextLevel = xpToNextLevel;
    }

    //Appearance
    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getBodyTrait() {
        return bodyTrait;
    }

    public void setBodyTrait(String bodyTrait) {
        this.bodyTrait = bodyTrait;
    }

    public String getBodyTrait2() {
        return bodyTrait2;
    }

    public void setBodyTrait2(String bodyTrait2) {
        this.bodyTrait2 = bodyTrait2;
    }

    public String getHairStyle() {
        return hairStyle;
    }

    public void setHairStyle(String hairStyle) {
        this.hairStyle = hairStyle;
    }

    public String getHairColor() {
        return hairColor;
    }

    public void setHairColor(String hairColor) {
        this.hairColor = hairColor;
    }

    public String getEyeColor() {
        return eyeColor;
    }

    public void setEyeColor(String eyeColor) {
        this.eyeColor = eyeColor;
    }

    public String getComplexion() {
        return complexion;
    }

    public void setComplexion(String complexion) {
        this.complexion = complexion;
    }

    public String getLineage() {
        return lineage;
    }

    public void setLineage(String lineage) {
        this.lineage = lineage;
    }

    public String getFacialHair() {
        return facialHair;
    }

    public void setFacialHair(String facialHair) {
        this.facialHair = facialHair;
    }

    public boolean isHasWings() {
        return hasWings;
    }

    public void setHasWings(boolean hasWings) {
        this.hasWings = hasWings;
    }

    public String getWingType() {
        return wingType;
    }

    public void setWingType(String wingType) {
        this.wingType = wingType;
    }

    //Inventory

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public Clothing getHeadGear() {
        return headGear;
    }

    public void setHeadGear(Clothing headGear) {
        this.headGear = headGear;
    }

    public Clothing getClothing() {
        return clothing;
    }

    public void setClothing(Clothing clothing) {
        this.clothing = clothing;
    }

    public ArrayList<InventoryItem> getInventory() {
        return inventory;
    }

    public void setInventory(ArrayList<InventoryItem> inventory) {
        this.inventory = inventory;
    }

    public Weapon getEquippedRangedWeapon() {
        return equippedRangedWeapon;
    }

    public void setEquippedRangedWeapon(Weapon equippedRangedWeapon) {
        this.equippedRangedWeapon = equippedRangedWeapon;
    }

    public Weapon getEquippedMeleeWeapon() {
        return equippedMeleeWeapon;
    }

    public void setEquippedMeleeWeapon(Weapon equippedMeleeWeapon) {
        this.equippedMeleeWeapon = equippedMeleeWeapon;
    }

    public Armor getEquippedArmor() {
        return equippedArmor;
    }

    public void setEquippedArmor(Armor equippedArmor) {
        this.equippedArmor = equippedArmor;
    }

    public int getMaxInventoryWeight() {
        return maxInventoryWeight;
    }

    public void setMaxInventoryWeight(int maxInventoryWeight) {
        this.maxInventoryWeight = maxInventoryWeight;
    }

    public int getInventoryWeight() {
        return inventoryWeight;
    }

    public void setInventoryWeight(int inventoryWeight) {
        this.inventoryWeight = inventoryWeight;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    public int getDaysPassed() {
        return daysPassed;
    }

    //RELATIONS

    public int getCharlotteRep() {
        return charlotteRep;
    }

    public void setCharlotteRep(int charlotteRep) {
        this.charlotteRep = charlotteRep;
    }
}
