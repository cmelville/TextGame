package com.cmm.textgame.objects;

/**
 * Created by Chris on 9/16/2016.
 */
public abstract class Weapon extends Item{
    private int damMin;
    private int damMax;
    private int pen;

    public Weapon(String name, String contextName, String description, int price, int weight, String specialRules, int damMin, int damMax, int pen) {
        super(name, contextName, description, price, weight, specialRules);
        this.damMin = damMin;
        this.damMax = damMax;
        this.pen = pen;
    }

    public abstract void useItem(Player player);

    public String importantStats(){
        return "Dam: "+damMin+"-"+damMax+"\tPen: "+pen;
    }
}
