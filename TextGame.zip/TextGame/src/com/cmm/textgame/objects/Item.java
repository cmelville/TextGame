package com.cmm.textgame.objects;

/**
 * Created by Chris on 9/14/2016.
 */
public abstract class Item implements InventoryItem {
    private String name;
    private String contextName;
    private String description;
    private int price;
    private int weight;
    private String specialRules; //Bonuses/Negatives to scores or status, ex "b=10,dodge=f"

    public Item(String name, String contextName, String description, int price, int weight, String specialRules) {
        this.name = name;
        this.contextName = contextName;
        this.description = description;
        this.price = price;
        this.weight = weight;
        this.specialRules = specialRules;
    }
    public int sellItem(Player player){
        player.getInventory().remove(this);
        return price*((player.getChaModifier()*2)/10);
    }

    public String getName() {
        return name;
    }

    public String getContextName() {
        return contextName;
    }

    public String getDescription() {
        return description;
    }

    public int getPrice() {
        return price;
    }

    public int getWeight() {
        return weight;
    }

    public String getSpecialRules() {
        return specialRules;
    }

    public abstract void useItem(Player player);

    public abstract String importantStats();

    @Override
    public String toString() {
        return "Item{" +
                "name='" + name + "}";
    }
}
