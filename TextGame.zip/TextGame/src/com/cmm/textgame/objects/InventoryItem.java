package com.cmm.textgame.objects;

/**
 * Created by Chris on 9/18/2016.
 */
public interface InventoryItem {
    String getName();
    String getDescription();
    String getSpecialRules();
    String importantStats();
    int getPrice();
    int getWeight();
    void useItem(Player player);
}
