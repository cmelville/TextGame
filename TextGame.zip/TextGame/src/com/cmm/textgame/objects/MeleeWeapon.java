package com.cmm.textgame.objects;

/**
 * Created by Chris on 9/16/2016.
 */
public class MeleeWeapon extends Weapon{
    public MeleeWeapon(String name, String contextName, String description, int price, int weight, String specialRules, int damMin, int damMax, int pen) {
        super(name, contextName, description, price, weight, specialRules, damMin, damMax, pen);
    }

    @Override
    public void useItem(Player player) {
        if(player.getEquippedMeleeWeapon() == null){
            player.setEquippedMeleeWeapon(this);
            player.getInventory().remove(this);
        }else{
            player.getInventory().remove(this);
            player.getInventory().add(player.getEquippedMeleeWeapon());
            player.setEquippedMeleeWeapon(this);
            player.getInventory().remove(this);
        }
    }

    @Override
    public String importantStats() {
        return super.importantStats();
    }
}
