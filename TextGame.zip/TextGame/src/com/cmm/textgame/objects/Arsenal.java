package com.cmm.textgame.objects;

/**
 * Created by Chris on 9/17/2016.
 */
public class Arsenal {
    public RangedWeapon startingPistol = new RangedWeapon("Old .45 Pistol", "a rusty old .45", "An old Mustang .45, although outdated, they're still known for their reliability. It's a miracle this gun fires at all considering it's age and wear.", 50, 1, null, 5, 10, 0, 7, "120");
}