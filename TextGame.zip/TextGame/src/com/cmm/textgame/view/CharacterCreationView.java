package com.cmm.textgame.view;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;

/**
 * Created by Chris on 9/11/2016.
 */
public class CharacterCreationView {
    public CharacterCreationView(Stage primaryStage) {
        Parent root = null;
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(
                    getClass().getClassLoader().getResource("fxml/CharacterCreation.fxml"));

            root = fxmlLoader.load(
                    getClass().getClassLoader().getResourceAsStream("fxml/CharacterCreation.fxml"));

        } catch (IOException e) {
            e.printStackTrace();
        }

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Character Creation");
        primaryStage.show();
        primaryStage.addEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, new EventHandler<WindowEvent>(){
            @Override
            public void handle(WindowEvent we)
            {
                if (primaryStage != null)
                    primaryStage.close();
                System.exit(0);
            }
        });
    }
}
