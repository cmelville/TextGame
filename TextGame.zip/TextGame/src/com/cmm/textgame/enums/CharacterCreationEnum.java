package com.cmm.textgame.enums;

/**
 * Created by Chris on 9/11/2016.
 */
public enum CharacterCreationEnum {
    NAME, CLASS, GENDER
}
