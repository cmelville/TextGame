package com.cmm.textgame.controller;

import java.net.URL;
import java.util.ResourceBundle;

import com.cmm.textgame.enums.CharacterCreationEnum;
import com.cmm.textgame.main.Launcher;
import com.cmm.textgame.view.CharacterCreationView;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;

public class MainMenuController {

    @FXML // fx:id="quitButton"
    private Button quitButton; // Value injected by FXMLLoader

    @FXML // fx:id="newGameButton"
    private Button newGameButton; // Value injected by FXMLLoader


    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {

    }

    //methods called when the buttons are pressed
    @FXML
    void newGameButtonPressed(ActionEvent event) {
        newGameButton.setStyle("-fx-background-color: #e8e8e8;");
        new CharacterCreationView(Launcher.stage);
    }

    @FXML
    void quitButtonPressed(ActionEvent event) {
        quitButton.setStyle("-fx-background-color: #e8e8e8;");
        System.exit(500);
    }

    /**
    //#################################################
    void setUp(CharacterCreationEnum enum1){
        switch(enum1){
            case NAME:
                //Change the stuff in the scene to match the query for name.
                break;
            case CLASS:
                break;
            case GENDER:
                break;
        }
    }
     */

}
