package com.cmm.textgame.controller;

import com.cmm.textgame.main.Launcher;
import com.cmm.textgame.objects.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.Tooltip;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.Random;


public class PrimarySceneController {
    @FXML
    private AnchorPane userInterface;

    @FXML
    private StackPane confirmationBox;

    @FXML
    private Button confirmationCancel;

    @FXML
    private Button confirmationConfirm;


    @FXML
    private GridPane buttonGridPane;



    @FXML
    private Text playerName;



    @FXML
    private Text balSkill;

    @FXML
    private Text wepSkill;

    @FXML
    private Text strSkill;

    @FXML
    private Text endSkill;

    @FXML
    private Text agSkill;

    @FXML
    private Text intSkill;

    @FXML
    private Text chaSkill;



    @FXML
    private Text weaponName;

    @FXML
    private Text armorName;



    @FXML
    private Rectangle healthBar;

    @FXML
    private Text healthNumber;



    @FXML
    private Rectangle xpBar;

    @FXML
    private Text xpNumber;

    @FXML
    private Text playerLevel;


    @FXML
    private Text currentInv;

    @FXML
    private Text maxInv;


    @FXML
    private Button invButton1;

    @FXML
    private Button invButtonX1;

    @FXML
    private Tooltip invButton1ToolTip;


    @FXML
    private Button invButton2;

    @FXML
    private Button invButtonX2;

    @FXML
    private Tooltip invButton2ToolTip;


    @FXML
    private Button invButton3;

    @FXML
    private Button invButtonX3;

    @FXML
    private Tooltip invButton3ToolTip;


    @FXML
    private Button invButton4;

    @FXML
    private Button invButtonX4;

    @FXML
    private Tooltip invButton4ToolTip;


    @FXML
    private Button invButton5;

    @FXML
    private Button invButtonX5;

    @FXML
    private Tooltip invButton5ToolTip;


    @FXML
    private Button invButton6;

    @FXML
    private Button invButtonX6;

    @FXML
    private Tooltip invButton6ToolTip;


    @FXML
    private Button invButton7;

    @FXML
    private Button invButtonX7;

    @FXML
    private Tooltip invButton7ToolTip;


    @FXML
    private Button invButton8;

    @FXML
    private Button invButtonX8;

    @FXML
    private Tooltip invButton8ToolTip;


    @FXML
    private Button invButton9;

    @FXML
    private Button invButtonX9;

    @FXML
    private Tooltip invButton9ToolTip;


    @FXML
    private Button invButton10;

    @FXML
    private Button invButtonX10;

    @FXML
    private Tooltip invButton10ToolTip;


    @FXML
    private Button invButton11;

    @FXML
    private Button invButtonX11;

    @FXML
    private Tooltip invButton11ToolTip;


    @FXML
    private Button invButton12;

    @FXML
    private Button invButtonX12;

    @FXML
    private Tooltip invButton12ToolTip;


    @FXML
    private Button invButton13;

    @FXML
    private Button invButtonX13;

    @FXML
    private Tooltip invButton13ToolTip;


    @FXML
    private Button invButton14;

    @FXML
    private Button invButtonX14;

    @FXML
    private Tooltip invButton14ToolTip;


    @FXML
    private Button invButton15;

    @FXML
    private Button invButtonX15;

    @FXML
    private Tooltip invButton15ToolTip;


    @FXML
    private Button invButton16;

    @FXML
    private Button invButtonX16;

    @FXML
    private Tooltip invButton16ToolTip;


    @FXML
    private Button invButtonBack;

    @FXML
    private Button invButtonNext;





    @FXML
    private Text credits;

    @FXML
    private Text time;


    @FXML
    private Button levelUpButton;

    @FXML
    private Button characterButton;



    @FXML
    private Button menuButton;

    @FXML
    private Button optionsButton;



    @FXML
    private StackPane locationMenu;

    @FXML
    private Text generalLocation;

    @FXML
    private Text specificLocation;



    @FXML
    private ImageView background;

    @FXML
    private ImageView characterImage;

    @FXML
    private TextArea textArea;

    @FXML
    private Text itemDetails;

    @FXML
    private StackPane inventoryFullBox;

    @FXML
    private Button takeButton;

    @FXML
    private Button leaveItemButton;


    Player player = Launcher.player;

    public void addItemToPlayerInventory(InventoryItem item){
        if(player.getInventoryWeight()+item.getWeight()>player.getMaxInventoryWeight()){
            inventoryFull(item);
        }
        else{
            player.addItemToInventory(item);
        }
        updatePlayerInfo();
    }

    public void askForConfirmation(InventoryItem item){
        confirmationBox.setVisible(true);
        userInterface.setDisable(true);
        inventoryFullBox.setDisable(true);
        confirmationConfirm.setOnAction(event -> {
            confirmationBox.setVisible(false);
            userInterface.setDisable(false);
            player.removeItemFromInventory(item);
            invButton1.setText("");
            invButton1.setVisible(false);
            invButtonX1.setVisible(false);
            inventoryFullBox.setDisable(false);
            clearInventoryScene();
            updatePlayerInfo();
        });
        confirmationCancel.setOnAction(event -> {
            confirmationBox.setVisible(false);
            userInterface.setDisable(false);
            inventoryFullBox.setDisable(false);
        });
    }

    public void inventoryFull(InventoryItem item){
        inventoryFullBox.setVisible(true);
        buttonGridPane.setDisable(true);
        menuButton.setDisable(true);
        characterButton.setDisable(true);
        optionsButton.setDisable(true);
        itemDetails.setText(item.getName()+" - \nWeight: "+item.getWeight()+"\tPrice: "+item.getPrice()+"\n"+item.getDescription());
        takeButton.setOnAction(event -> {
            if(player.getInventoryWeight()+item.getWeight()<=player.getMaxInventoryWeight()){
                player.addItemToInventory(item);
                inventoryFullBox.setVisible(false);
                buttonGridPane.setDisable(false);
                menuButton.setDisable(false);
                characterButton.setDisable(false);
                optionsButton.setDisable(false);
                updatePlayerInfo();
            }
        });
        leaveItemButton.setOnAction(event -> {
            inventoryFullBox.setVisible(false);
            buttonGridPane.setDisable(false);
            menuButton.setDisable(false);
            characterButton.setDisable(false);
            optionsButton.setDisable(false);
        });
    }

    public void clearInventoryScene(){
        invButton1.setText("");
        invButton1.setVisible(false);
        invButtonX1.setVisible(false);
        invButton2.setText("");
        invButton2.setVisible(false);
        invButtonX2.setVisible(false);
        invButton3.setText("");
        invButton3.setVisible(false);
        invButtonX3.setVisible(false);
        invButton4.setText("");
        invButton4.setVisible(false);
        invButtonX4.setVisible(false);
        invButton5.setText("");
        invButton5.setVisible(false);
        invButtonX5.setVisible(false);
        invButton6.setText("");
        invButton6.setVisible(false);
        invButtonX6.setVisible(false);
        invButton7.setText("");
        invButton7.setVisible(false);
        invButtonX7.setVisible(false);
        invButton8.setText("");
        invButton8.setVisible(false);
        invButtonX8.setVisible(false);
        invButton9.setText("");
        invButton9.setVisible(false);
        invButtonX9.setVisible(false);
        invButton10.setText("");
        invButton10.setVisible(false);
        invButtonX10.setVisible(false);
        invButton11.setText("");
        invButton11.setVisible(false);
        invButtonX11.setVisible(false);
        invButton12.setText("");
        invButton12.setVisible(false);
        invButtonX12.setVisible(false);
        invButton13.setText("");
        invButton13.setVisible(false);
        invButtonX13.setVisible(false);
        invButton14.setText("");
        invButton14.setVisible(false);
        invButtonX14.setVisible(false);
        invButton15.setText("");
        invButton15.setVisible(false);
        invButtonX15.setVisible(false);
        invButton16.setText("");
        invButton16.setVisible(false);
        invButtonX16.setVisible(false);
        invButtonBack.setVisible(false);
        invButtonNext.setVisible(false);


    }

    public void showPlayerInventory(int startingIndex){
        if(player.getInventory().size()>startingIndex+16){
            invButtonNext.setVisible(true);
            invButtonNext.setOnAction(event -> {
                invButtonNext.setVisible(false);
                clearInventoryScene();
                showPlayerInventory(startingIndex+16);
            });
        }
        if(startingIndex-16>=0){
            invButtonBack.setVisible(true);
            invButtonBack.setOnAction(event -> {
                invButtonBack.setVisible(false);
                clearInventoryScene();
                showPlayerInventory(startingIndex-16);
            });
        }
        if(player.getInventory().size()>startingIndex) {
            InventoryItem item = player.getInventory().get(startingIndex);
            invButton1ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton1.setText(item.getName());
            invButton1.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX1.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton1.setVisible(true);
            invButtonX1.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+1) {
            InventoryItem item = player.getInventory().get(startingIndex+1);
            invButton2ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton2.setText(item.getName());
            invButton2.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX2.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton2.setVisible(true);
            invButtonX2.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+2) {
            InventoryItem item = player.getInventory().get(startingIndex+2);
            invButton3ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton3.setText(item.getName());
            invButton3.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX3.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton3.setVisible(true);
            invButtonX3.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+3) {
            InventoryItem item = player.getInventory().get(startingIndex+3);
            invButton4ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton4.setText(item.getName());
            invButton4.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX4.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton4.setVisible(true);
            invButtonX4.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+4) {
            InventoryItem item = player.getInventory().get(startingIndex+4);
            invButton5ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton5.setText(item.getName());
            invButton5.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX5.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton5.setVisible(true);
            invButtonX5.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+5) {
            InventoryItem item = player.getInventory().get(startingIndex+5);
            invButton6ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton6.setText(item.getName());
            invButton6.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX6.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton6.setVisible(true);
            invButtonX6.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+6) {
            InventoryItem item = player.getInventory().get(startingIndex+6);
            invButton7ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton7.setText(item.getName());
            invButton7.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX7.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton7.setVisible(true);
            invButtonX7.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+7) {
            InventoryItem item = player.getInventory().get(startingIndex+7);
            invButton8ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton8.setText(item.getName());
            invButton8.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX8.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton8.setVisible(true);
            invButtonX8.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+8) {
            InventoryItem item = player.getInventory().get(startingIndex+8);
            invButton9ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton9.setText(item.getName());
            invButton9.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX9.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton9.setVisible(true);
            invButtonX9.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+9) {
            InventoryItem item = player.getInventory().get(startingIndex+9);
            invButton10ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton10.setText(item.getName());
            invButton10.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX10.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton10.setVisible(true);
            invButtonX10.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+10) {
            InventoryItem item = player.getInventory().get(startingIndex+10);
            invButton11ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton11.setText(item.getName());
            invButton11.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX11.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton11.setVisible(true);
            invButtonX11.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+11) {
            InventoryItem item = player.getInventory().get(startingIndex+11);
            invButton12ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton12.setText(item.getName());
            invButton12.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX12.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton12.setVisible(true);
            invButtonX12.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+12) {
            InventoryItem item = player.getInventory().get(startingIndex+12);
            invButton13ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton13.setText(item.getName());
            invButton13.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX13.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton13.setVisible(true);
            invButtonX13.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+13) {
            InventoryItem item = player.getInventory().get(startingIndex+13);
            invButton14ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton14.setText(item.getName());
            invButton14.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX14.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton14.setVisible(true);
            invButtonX14.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+14) {
            InventoryItem item = player.getInventory().get(startingIndex+14);
            invButton15ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton15.setText(item.getName());
            invButton15.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX15.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton15.setVisible(true);
            invButtonX15.setVisible(true);
        }
        if(player.getInventory().size()>startingIndex+15) {
            InventoryItem item = player.getInventory().get(startingIndex+15);
            invButton16ToolTip.setText(item.getName()+" - \nW: "+item.getWeight()+"\t\t\tP: "+item.getPrice()+"\n"+item.importantStats()+"\n"+item.getDescription());
            invButton16.setText(item.getName());
            invButton16.setOnAction(event -> {
                item.useItem(player);
                updatePlayerInfo();
            });
            invButtonX16.setOnAction(event -> {
                askForConfirmation(item);
            });
            invButton16.setVisible(true);
            invButtonX16.setVisible(true);
        }

    }

    public void updatePlayerInfo(){
        player.calculateModifiers();
        playerName.setText(player.getName());
        balSkill.setText(""+player.getBalSkill());
        wepSkill.setText(""+player.getWepSkill());
        strSkill.setText(""+player.getStrSkill());
        endSkill.setText(""+player.getEndSkill());
        agSkill.setText(""+player.getAgSkill());
        intSkill.setText(""+player.getIntSkill());
        chaSkill.setText(""+player.getChaSkill());
        if(player.getEquippedArmor()==null){
            armorName.setText("None Equipped");
        }else{
            armorName.setText(""+player.getEquippedArmor().getName());
        }
        if(player.getEquippedRangedWeapon()==null&&player.getEquippedMeleeWeapon()==null){
            weaponName.setText("None Equipped");
        }else if(player.getEquippedMeleeWeapon()==null){
            weaponName.setText(player.getEquippedRangedWeapon().getName());
        }else if(player.getEquippedRangedWeapon()==null){
            weaponName.setText(player.getEquippedMeleeWeapon().getName());
        }else{
            weaponName.setText(""+player.getEquippedRangedWeapon().getName()+"\n"+player.getEquippedMeleeWeapon().getName());
        }
        healthBar.setWidth(player.calculateHealthBarPercentage());
        healthNumber.setText(""+player.getCurrentHealth());
        playerLevel.setText(""+player.getLevel());
        xpBar.setWidth(player.calculateXpBarPercentage());
        xpNumber.setText(""+player.getCurrentXP());
        time.setText(player.getTime());
        credits.setText(""+player.getCredits());
        generalLocation.setText(player.getGeneralLocation());
        specificLocation.setText(player.getSpecificLocation());
        player.calculateCurrentInventoryWeight();
        currentInv.setText(""+player.getInventoryWeight());
        maxInv.setText(""+player.getMaxInventoryWeight());
        showPlayerInventory(0);
    }


    @FXML // This method is called by the FXMLLoader when initialization is complete
    public void initialize() {
        player.setTime("9:35");
        parse("assets/scenes/introduction/introduction1.xml");
        updatePlayerInfo();
    }







    @FXML
    void levelUpButtonPressed(ActionEvent event){
        player.setSkillPointsSpent(0);
        characterSkillIncrease.setVisible(true);
        levelUpButton.setText("CONFIRM");
        levelUpButton.setOnAction(event1 -> {
            levelUpButton.setText("LEVEL UP");
            player.setBalSkill(Integer.parseInt(balSkill2.getText()));
            player.setWepSkill(Integer.parseInt(wepSkill2.getText()));
            player.setStrSkill(Integer.parseInt(strSkill2.getText()));
            player.setEndSkill(Integer.parseInt(endSkill2.getText()));
            player.setAgSkill(Integer.parseInt(agSkill2.getText()));
            player.setIntSkill(Integer.parseInt(intSkill2.getText()));
            player.setChaSkill(Integer.parseInt(chaSkill2.getText()));
            player.setSkillPointsLeft(player.getSkillPointsLeft()-player.getSkillPointsSpent());
            player.setSkillPointsSpent(0);
            characterSkillIncrease.setVisible(false);
            levelUpButton.setOnAction(event2 -> {
                levelUpButtonPressed(event2);
            });
            updatePlayerInfo();
        });
        pointsLeft.setText(""+player.getSkillPointsLeft());
        balSkill2.setText(""+player.getBalSkill());
        wepSkill2.setText(""+player.getWepSkill());
        strSkill2.setText(""+player.getStrSkill());
        endSkill2.setText(""+player.getEndSkill());
        agSkill2.setText(""+player.getAgSkill());
        intSkill2.setText(""+player.getIntSkill());
        chaSkill2.setText(""+player.getChaSkill());

        updatePlayerInfo();
    }

    private boolean displayingCharacterInfo = false;
    private String oldTextArea;
    @FXML
    void characterButtonPressed(ActionEvent event){
        if(!displayingCharacterInfo){
            oldTextArea = textArea.getText();
            textArea.setText(player.describePlayer());
            displayingCharacterInfo = true;
            if(player.getSkillPointsLeft()>0){
                levelUpButton.setText("LEVEL UP");
                levelUpButton.setOnAction(event1 -> {
                    levelUpButtonPressed(event);
                });
                levelUpButton.setVisible(true);
            }
        }else{
            textArea.setText(oldTextArea);
            displayingCharacterInfo = false;
            levelUpButton.setVisible(false);
            characterSkillIncrease.setVisible(false);
        }
    }






    //LEVELING UP
    @FXML
    private HBox characterSkillIncrease;

    @FXML
    private Button balSkillUp;

    @FXML
    private Text balSkill2;

    @FXML
    private Button balSkillDown;


    @FXML
    private Button wepSkillUp;

    @FXML
    private Text wepSkill2;

    @FXML
    private Button wepSkillDown;


    @FXML
    private Button strSkillUp;

    @FXML
    private Text strSkill2;

    @FXML
    private Button strSkillDown;


    @FXML
    private Button endSkillUp;

    @FXML
    private Text endSkill2;

    @FXML
    private Button endSkillDown;


    @FXML
    private Button agSkillUp;

    @FXML
    private Text agSkill2;

    @FXML
    private Button agSkillDown;


    @FXML
    private Button intSkillUp;

    @FXML
    private Text intSkill2;

    @FXML
    private Button intSkillDown;


    @FXML
    private Button chaSkillUp;

    @FXML
    private Text chaSkill2;

    @FXML
    private Button chaSkillDown;

    @FXML
    private Text pointsLeft;

    @FXML
    void balSkillUpPressed(ActionEvent event){
        if(player.getSkillPointsSpent()<player.getSkillPointsLeft()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()+1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            balSkill2.setText(""+(Integer.parseInt(balSkill2.getText())+1));
        }
    }

    @FXML
    void balSkillDownPressed(ActionEvent event){
        if(player.getSkillPointsSpent()>0&&Integer.parseInt(balSkill2.getText())>player.getBalSkill()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()-1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            balSkill2.setText(""+(Integer.parseInt(balSkill2.getText())-1));
        }
    }

    @FXML
    void wepSkillUpPressed(ActionEvent event){
        if(player.getSkillPointsSpent()<player.getSkillPointsLeft()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()+1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            wepSkill2.setText(""+(Integer.parseInt(wepSkill2.getText())+1));
        }
    }

    @FXML
    void wepSkillDownPressed(ActionEvent event){
        if(player.getSkillPointsSpent()>0&&Integer.parseInt(wepSkill2.getText())>player.getWepSkill()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()-1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            wepSkill2.setText(""+(Integer.parseInt(wepSkill2.getText())-1));
        }
    }

    @FXML
    void strSkillUpPressed(ActionEvent event){
        if(player.getSkillPointsSpent()<player.getSkillPointsLeft()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()+1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            strSkill2.setText(""+(Integer.parseInt(strSkill2.getText())+1));
        }
    }

    @FXML
    void strSkillDownPressed(ActionEvent event){
        if(player.getSkillPointsSpent()>0&&Integer.parseInt(strSkill2.getText())>player.getStrSkill()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()-1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            strSkill2.setText(""+(Integer.parseInt(strSkill2.getText())-1));
        }
    }

    @FXML
    void endSkillUpPressed(ActionEvent event){
        if(player.getSkillPointsSpent()<player.getSkillPointsLeft()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()+1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            endSkill2.setText(""+(Integer.parseInt(endSkill2.getText())+1));
        }
    }

    @FXML
    void endSkillDownPressed(ActionEvent event){
        if(player.getSkillPointsSpent()>0&&Integer.parseInt(endSkill2.getText())>player.getEndSkill()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()-1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            endSkill2.setText(""+(Integer.parseInt(endSkill2.getText())-1));
        }
    }

    @FXML
    void agSkillUpPressed(ActionEvent event){
        if(player.getSkillPointsSpent()<player.getSkillPointsLeft()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()+1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            agSkill2.setText(""+(Integer.parseInt(agSkill2.getText())+1));
        }
    }

    @FXML
    void agSkillDownPressed(ActionEvent event){
        if(player.getSkillPointsSpent()>0&&Integer.parseInt(agSkill2.getText())>player.getAgSkill()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()-1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            agSkill2.setText(""+(Integer.parseInt(agSkill2.getText())-1));
        }
    }

    @FXML
    void intSkillUpPressed(ActionEvent event){
        if(player.getSkillPointsSpent()<player.getSkillPointsLeft()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()+1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            intSkill2.setText(""+(Integer.parseInt(intSkill2.getText())+1));
        }
    }

    @FXML
    void intSkillDownPressed(ActionEvent event){
        if(player.getSkillPointsSpent()>0&&Integer.parseInt(intSkill2.getText())>player.getIntSkill()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()-1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            intSkill2.setText(""+(Integer.parseInt(intSkill2.getText())-1));
        }
    }

    @FXML
    void chaSkillUpPressed(ActionEvent event){
        if(player.getSkillPointsSpent()<player.getSkillPointsLeft()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()+1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            chaSkill2.setText(""+(Integer.parseInt(chaSkill2.getText())+1));
        }
    }

    @FXML
    void chaSkillDownPressed(ActionEvent event){
        if(player.getSkillPointsSpent()>0&&Integer.parseInt(chaSkill2.getText())>player.getChaSkill()){
            player.setSkillPointsSpent(player.getSkillPointsSpent()-1);
            pointsLeft.setText(""+(player.getSkillPointsLeft()-player.getSkillPointsSpent()));
            chaSkill2.setText(""+(Integer.parseInt(chaSkill2.getText())-1));
        }
    }


    public void parse(String filePath) {
        try {
            buttonGridPane.getChildren().clear();
            File fXmlFile = new File(filePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);

            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("location");

            NodeList nList2 = doc.getElementsByTagName("button");

            if(doc.getElementsByTagName("increase").item(0)!=null) {
                String[] increaseUnparsed = doc.getElementsByTagName("increase").item(0).getTextContent().split("%");
                String skill = increaseUnparsed[0];
                int amount = Integer.parseInt(increaseUnparsed[1]);
                if(skill.equals("charlotteRep")){
                    System.out.println(player.getCharlotteRep());
                    player.setCharlotteRep(player.getCharlotteRep()+amount);
                    System.out.println(player.getCharlotteRep());
                }
            }
            for (int temp = 0; temp < nList.getLength(); temp++) {

                Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element eElement = (Element) nNode;

                    player.setGeneralLocation(eElement.getAttribute("gen"));
                    player.setSpecificLocation(eElement.getAttribute("spec"));
                    Image image = new Image("images/backgroundImages/"+eElement.getAttribute("background"));
                    background.setImage(image);
                    if(!eElement.getAttribute("characterImage").equals("")){
                        Image image2 = new Image("images/characterImages/"+eElement.getAttribute("characterImage"));
                        characterImage.setImage(image2);
                    }
                    String text = eElement.getElementsByTagName("textArea").item(0).getTextContent();
                    text = text.replaceAll("%name",player.getName());
                    text = text.replaceAll("%weaponContext",player.getEquippedRangedWeapon().getContextName());
                    text = text.replaceAll("%weaponName",player.getEquippedRangedWeapon().getName());
                    textArea.setText(""+text);
                }
            }

            for (int temp = 0; temp < nList2.getLength(); temp++) {

                Node nNode = nList2.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                Element eElement = (Element) nNode;

                    String index = eElement.getAttribute("index");
                    int column = Character.getNumericValue(index.charAt(0));
                    int row = Character.getNumericValue(index.charAt(1));
                    Button newButton = new Button(eElement.getAttribute("title"));
                    newButton.setMaxSize(120.0,31.0);
                    newButton.setMinSize(120.0,31.0);
                    newButton.getStylesheets().add("cssStyleSheets/TransitionButton.css");
                    buttonGridPane.add(newButton,column,row);
                    String actionType = eElement.getElementsByTagName("actionType").item(0).getTextContent();
                    String action = eElement.getElementsByTagName("action").item(0).getTextContent();
                    if(actionType.equals("newRangedWeapon")){
                        String[] splitDetails = action.split(",");
                        if(splitDetails[5].equals("null")){
                            splitDetails[5] = null;
                        }
                        RangedWeapon newWeapon = new RangedWeapon(splitDetails[0],splitDetails[1],splitDetails[2],Integer.parseInt(splitDetails[3]),Integer.parseInt(splitDetails[4]),splitDetails[5],Integer.parseInt(splitDetails[6]),Integer.parseInt(splitDetails[7]),Integer.parseInt(splitDetails[8]),Integer.parseInt(splitDetails[9]),splitDetails[10]);
                        newButton.setOnAction(event -> {
                            addItemToPlayerInventory(newWeapon);
                        });
                    }
                    if(actionType.equals("newMeleeWeapon")){
                        String[] splitDetails = action.split(",");
                        if(splitDetails[5].equals("null")){
                            splitDetails[5] = null;
                        }
                        MeleeWeapon newWeapon = new MeleeWeapon(splitDetails[0],splitDetails[1],splitDetails[2],Integer.parseInt(splitDetails[3]),Integer.parseInt(splitDetails[4]),splitDetails[5],Integer.parseInt(splitDetails[6]),Integer.parseInt(splitDetails[7]),Integer.parseInt(splitDetails[8]));
                        newButton.setOnAction(event -> {
                            addItemToPlayerInventory(newWeapon);
                        });
                    }
                    if(actionType.equals("switchScene")){
                        String xmlPath = "assets/scenes/"+action+".xml";
                        newButton.setOnAction(event -> {
                            player.passTime(eElement.getAttribute("time"));
                            parse(xmlPath);
                        });
                    }
                    if(actionType.equals("skillTest")){
                        String[] splitAction = action.split("%");
                        String onSuccess = "assets/scenes/"+splitAction[0]+".xml";
                        String onFail = "assets/scenes/"+splitAction[1]+".xml";
                        Random rand = new Random();
                        int modifier = 0;
                        newButton.getStylesheets().add("cssStyleSheets/AverageSkillButton.css");
                        if(eElement.getAttribute("mod").equals("vEasy")){
                            modifier = 20;
                            newButton.getStylesheets().add("cssStyleSheets/VEasySkillButton.css");
                        }else if(eElement.getAttribute("mod").equals("easy")){
                            modifier = 10;
                            newButton.getStylesheets().add("cssStyleSheets/EasySkillButton.css");
                        }else if(eElement.getAttribute("mod").equals("med")){
                            modifier = -10;
                            newButton.getStylesheets().add("cssStyleSheets/MediumSkillButton.css");
                        }else if(eElement.getAttribute("mod").equals("hard")){
                            modifier = -20;
                            newButton.getStylesheets().add("cssStyleSheets/HardSkillButton.css");
                        }
                        final int mod = modifier;
                        if(eElement.getAttribute("skill").equals("bal")){
                            newButton.setOnAction(event -> {
                                int roll = rand.nextInt(100) + 1;
                                if(roll-mod<=player.getBalSkill()){
                                    parse(onSuccess);
                                }else{
                                    parse(onFail);
                                }
                            });
                        }
                        if(eElement.getAttribute("skill").equals("wep")){
                            newButton.setOnAction(event -> {
                                int roll = rand.nextInt(100) + 1;
                                if(roll-mod<=player.getWepSkill()){
                                    parse(onSuccess);
                                }else{
                                    parse(onFail);
                                }
                            });
                        }
                        if(eElement.getAttribute("skill").equals("str")){
                            newButton.setOnAction(event -> {
                                int roll = rand.nextInt(100) + 1;
                                if(roll-mod<=player.getStrSkill()){
                                    parse(onSuccess);
                                }else{
                                    parse(onFail);
                                }
                            });
                        }
                        if(eElement.getAttribute("skill").equals("end")){
                            newButton.setOnAction(event -> {
                                int roll = rand.nextInt(100) + 1;
                                if(roll-mod<=player.getEndSkill()){
                                    parse(onSuccess);
                                }else{
                                    parse(onFail);
                                }
                            });
                        }
                        if(eElement.getAttribute("skill").equals("ag")){
                            newButton.setOnAction(event -> {
                                int roll = rand.nextInt(100) + 1;
                                if(roll-mod<=player.getAgSkill()){
                                    parse(onSuccess);
                                }else{
                                    parse(onFail);
                                }
                            });
                        }
                        if(eElement.getAttribute("skill").equals("int")){
                            newButton.setOnAction(event -> {
                                int roll = rand.nextInt(100) + 1;
                                if(roll-mod<=player.getIntSkill()){
                                    parse(onSuccess);
                                }else{
                                    parse(onFail);
                                }
                            });
                        }
                        if(eElement.getAttribute("skill").equals("cha")){
                            newButton.setOnAction(event -> {
                                int roll = rand.nextInt(100) + 1;
                                if(roll-mod<=player.getChaSkill()){
                                    parse(onSuccess);
                                }else{
                                    parse(onFail);
                                }
                            });
                        }
                    }
                }
            }
            updatePlayerInfo();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
