package com.cmm.textgame.controller;

import java.awt.*;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.ResourceBundle;

import com.cmm.textgame.enums.CharacterCreationEnum;
import com.cmm.textgame.main.Launcher;
import com.cmm.textgame.objects.*;
import com.cmm.textgame.view.CharacterCreationView;
import com.cmm.textgame.view.PrimarySceneView;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class CharacterCreationController {
    //Player player = new Player();
    Player player = Launcher.player;
    private String currentArea = "";

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    private Text playerLevel;

    @FXML // fx:id="button25"
    private Button button25; // Value injected by FXMLLoader

    @FXML // fx:id="button24"
    private Button button24; // Value injected by FXMLLoader

    @FXML // fx:id="button26"
    private Button button26; // Value injected by FXMLLoader

    @FXML // fx:id="button21"
    private Button button21; // Value injected by FXMLLoader

    @FXML // fx:id="button23"
    private Button button23; // Value injected by FXMLLoader

    @FXML // fx:id="button22"
    private Button button22; // Value injected by FXMLLoader

    @FXML // fx:id="agSkill"
    private Text agSkill; // Value injected by FXMLLoader

    @FXML // fx:id="weaponName"
    private Text weaponName; // Value injected by FXMLLoader

    @FXML // fx:id="enterName"
    private TextField enterName; // Value injected by FXMLLoader

    @FXML // fx:id="characterButton"
    private Button characterButton; // Value injected by FXMLLoader

    @FXML // fx:id="credits"
    private Text credits; // Value injected by FXMLLoader

    @FXML // fx:id="endSkill"
    private Text endSkill; // Value injected by FXMLLoader

    @FXML // fx:id="intSkill"
    private Text intSkill; // Value injected by FXMLLoader

    @FXML // fx:id="button14"
    private Button button14; // Value injected by FXMLLoader

    @FXML // fx:id="button13"
    private Button button13; // Value injected by FXMLLoader

    @FXML // fx:id="button16"
    private Button button16; // Value injected by FXMLLoader

    @FXML // fx:id="button15"
    private Button button15; // Value injected by FXMLLoader

    @FXML // fx:id="healthNumber"
    private Text healthNumber; // Value injected by FXMLLoader

    @FXML // fx:id="playerName"
    private Text playerName; // Value injected by FXMLLoader

    @FXML // fx:id="xpNumber"
    private Text xpNumber; // Value injected by FXMLLoader

    @FXML // fx:id="button12"
    private Button button12; // Value injected by FXMLLoader

    @FXML // fx:id="strSkill"
    private Text strSkill; // Value injected by FXMLLoader

    @FXML // fx:id="button11"
    private Button button11; // Value injected by FXMLLoader

    @FXML // fx:id="healthBar"
    private Rectangle healthBar; // Value injected by FXMLLoader

    @FXML // fx:id="meanuButton"
    private Button meanuButton; // Value injected by FXMLLoader

    @FXML // fx:id="wepSkill"
    private Text wepSkill; // Value injected by FXMLLoader

    @FXML // fx:id="chaSkill"
    private Text chaSkill; // Value injected by FXMLLoader

    @FXML // fx:id="xpBar"
    private Rectangle xpBar; // Value injected by FXMLLoader

    @FXML // fx:id="balSkill"
    private Text balSkill; // Value injected by FXMLLoader

    @FXML // fx:id="armorName"
    private Text armorName; // Value injected by FXMLLoader

    @FXML // fx:id="time"
    private Text time; // Value injected by FXMLLoader

    @FXML
    private TextArea textArea;

    @FXML
    private VBox appearanceMenu;

    @FXML
    private ChoiceBox<String> raceChoiceBox;

    @FXML
    private ChoiceBox<String> ageChoiceBox;

    @FXML
    private ChoiceBox<String> bodyChoiceBox;

    @FXML
    private ChoiceBox<String> body2ChoiceBox;

    @FXML
    private ChoiceBox<String> hairStyleChoiceBox;

    @FXML
    private ChoiceBox<String> hairColorChoiceBox;

    @FXML
    private ChoiceBox<String> eyeColorChoiceBox;

    @FXML
    private ChoiceBox<String> complexionChoiceBox;

    @FXML
    private ChoiceBox<String> lineageChoiceBox;

    @FXML
    private ChoiceBox<String> facialHairChoiceBox;

    @FXML
    private HBox facialHairOption;

    /**
     * Buttons and Text used to increase the characters stats
     */
    @FXML
    private HBox characterSkillIncrease;

    @FXML
    private Text pointsLeft;

    private int skillPointsLeft = 70; //############################################################# SET TO 0 FOR DEBUGGING, SET BACK TO 70

    //Increase and decrease skills plane

    @FXML
    private Button balSkillUp;

    @FXML
    private Text balSkill2;

    @FXML
    private Button balSkillDown;


    @FXML
    private Button wepSkillUp;

    @FXML
    private Text wepSkill2;

    @FXML
    private Button wepSkillDown;


    @FXML
    private Button strSkillUp;

    @FXML
    private Text strSkill2;

    @FXML
    private Button strSkillDown;


    @FXML
    private Button endSkillUp;

    @FXML
    private Text endSkill2;

    @FXML
    private Button endSkillDown;


    @FXML
    private Button agSkillUp;

    @FXML
    private Text agSkill2;

    @FXML
    private Button agSkillDown;


    @FXML
    private Button intSkillUp;

    @FXML
    private Text intSkill2;

    @FXML
    private Button intSkillDown;


    @FXML
    private Button chaSkillUp;

    @FXML
    private Text chaSkill2;

    @FXML
    private Button chaSkillDown;




    /**
     * #############################
     * # LISTS OF APPEARANCE ITEMS #
     * #############################
     */

    private ArrayList<String> races = new ArrayList<String>(){{add("human");}};
    private ArrayList<String> age = new ArrayList<String>(){{add("random");add("ageless");add("young");add("teenaged");add("youthful");add("matured");add("dated");add("old");}};
    private ArrayList<String> bodyChoice = new ArrayList<String>();
    private ArrayList<String> body2Choice = new ArrayList<String>();

    private ArrayList<String> hairStyleMale = new ArrayList<String>(){{add("random");add("short well kept");add("short messy");add("disheveled");add("bushy");add("long");add("spiky");add("shaggy");add("fuzzy");add("tidy");add("professional");add("curly");add("loose");add("combed over");}};
    private ArrayList<String> hairStyleFemale = new ArrayList<String>(){{add("random");add("shoulder length");add("tied back");add("long flowing");add("fuzzy");add("elegant long");add("spiky");add("long strait");add("short strait");add("tidy");add("wavy");add("braided");}};

    private ArrayList<String> humanHairColor = new ArrayList<String>(){{add("random");add("blond");add("brown");add("black");add("grey");add("orange");add("silver");add("white");}};
    private ArrayList<String> demonHairColor = new ArrayList<String>(){{add("random");add("dark blue");add("orange");add("jet black");}};

    private ArrayList<String> humanEyeColor = new ArrayList<String>(){{add("random");add("amber");add("blue");add("brown");add("green");add("grey");add("hazel");add("violet");}};
    private ArrayList<String> demonEyeColor = new ArrayList<String>(){{add("random");add("red");add("orange");add("solid black");}};

    private ArrayList<String> humanComplexion = new ArrayList<String>(){{add("random");add("pale");add("freckled");add("fair");add("light");add("weathered");add("tanned");add("ruddy");add("olive");add("ebony");add("dark");}};
    private ArrayList<String> demonComplexion = new ArrayList<String>(){{add("random");add("blue tinted");add("red tinted");add("light purple");}};


    private ArrayList<String> lineage = new ArrayList<String>(){{add("random");add("craftsmen");add("chefs");add("farmers");add("hunters");add("mechanics");add("artists");add("musicians");add("policemen");add("businessmen");add("soldiers");add("prizefighters");add("gangsters");add("doctors");add("scientists");add("politicians");add("samurai");add("ninjas");add("nobility");}};

    private ArrayList<String> facialHair = new ArrayList<String>(){{add("random");add("large fuzzy Beard");add("trimmed beard");add("pair of mutton chops");add("fu manchu");add("handlebar mustache");add("curly mustache");add("tidy mustache");add("pencil mustache");add("toothbrush mustache");add("walrus mustache");add("soul patch");add("neck beard");add("goatee");}};

    /**
     *  SCENE SWITCHING
     *
     *  #################        ##########        ##############
     *  # NAMING/GENDER # <----> # SKILLS # <----> # APPEARANCE #
     *  #################        ##########        ##############
     *
     */

    //Utility functions
    private void resetAllButtons(){
        button11.setText("");
        button11.setVisible(false);
        button12.setText("");
        button12.setVisible(false);
        button13.setText("");
        button13.setVisible(false);
        button14.setText("");
        button14.setVisible(false);
        button15.setText("");
        button15.setVisible(false);
        button16.setText("");
        button16.setVisible(false);
        button21.setText("");
        button21.setVisible(false);
        button22.setText("");
        button22.setVisible(false);
        button23.setText("");
        button23.setVisible(false);
        button24.setText("");
        button24.setVisible(false);
        button25.setText("");
        button25.setVisible(false);
        button26.setText("");
        button26.setVisible(false);

    }

    private void resetAllChoiceBoxes() { //resets all Choice Box except race
        ArrayList emptyArray = new ArrayList(){{}};
        raceChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
        ageChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
        bodyChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
        body2ChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
        hairStyleChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
        hairColorChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
        eyeColorChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
        complexionChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
        lineageChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
        facialHairChoiceBox.setItems(FXCollections.observableArrayList(emptyArray));
    }

    private boolean allChoiceBoxesFull(){
        boolean isFull = true;
        if(raceChoiceBox.getValue() == null || ageChoiceBox.getValue() == null || bodyChoiceBox.getValue() == null
                || body2ChoiceBox.getValue() == null || hairStyleChoiceBox.getValue() == null || hairColorChoiceBox.getValue() == null
                || eyeColorChoiceBox.getValue() == null || complexionChoiceBox.getValue() == null || lineageChoiceBox.getValue() == null){
                isFull = false;
        }
        if(player.getGender().equals("male") && facialHairChoiceBox.getValue() == null){
            isFull = false;
        }
        return isFull;
    }





    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        resetAllButtons();
        currentArea = "characterNaming";
        button11.setText("MALE");
        button11.setVisible(true);
        button12.setText("FEMALE");
        button12.setVisible(true);
        textArea.setText("Welcome to the world of TextGame!\n" +
                "This world is an attempt to combine the fantasy genera associated with games such as D&D and Pathfinder, " +
                "with the gritty combat and skill tests found within games such as Dark Heresy and Rouge Trader.\n" +
                "I've played many games set in a medieval fantasy, i've played many games with a futuristic setting full" +
                " of spaceships and aliens, I have yet to find a mixture of both. This game is my perspective as to what" +
                " a world would be like if that same fantasy genera we're all familiar with was moved to a modern setting. \n\n" +
                "To begin your adventure, please enter your character name and gender!");
        enterName.setVisible(true);
        healthBar.setWidth(0);
        xpBar.setWidth(0);
    }





    @FXML
    void button11Pressed(ActionEvent event){
        if(currentArea.equals("characterNaming")&&!enterName.getText().equals("")&&!enterName.getText().equals(" ")&&enterName.getText().length()<18) { //naming -> SKILLS
            resetAllButtons();
            enterName.setVisible(false);
            pointsLeft.setText(""+skillPointsLeft);

            player.setBalSkill(20);
            balSkill.setText(""+player.getBalSkill());
            balSkill2.setText(""+player.getBalSkill());
            player.setWepSkill(20);
            wepSkill.setText(""+player.getWepSkill());
            wepSkill2.setText(""+player.getWepSkill());
            player.setStrSkill(20);
            strSkill.setText(""+player.getStrSkill());
            strSkill2.setText(""+player.getStrSkill());
            player.setEndSkill(20);
            endSkill.setText(""+player.getEndSkill());
            endSkill2.setText(""+player.getEndSkill());
            player.setAgSkill(20);
            agSkill.setText(""+player.getAgSkill());
            agSkill2.setText(""+player.getAgSkill());
            player.setIntSkill(20);
            intSkill.setText(""+player.getIntSkill());
            intSkill2.setText(""+player.getIntSkill());
            player.setChaSkill(20);
            chaSkill.setText(""+player.getChaSkill());
            chaSkill2.setText(""+player.getChaSkill());

            characterSkillIncrease.setVisible(true);
            player.setName(enterName.getText());
            playerName.setText(player.getName());
            player.setGender("male");
            textArea.setText("\n" +
                    "Ballistic Skill (BAL) -\n" +
                    "        A higher Ballistic Skill will make it easier to hit targets at range. \n"+
                    "Weapon Skill (WEP) -\n" +
                    "        A higher Weapon Skill will make it easier to hit targets in melee combat. \n" +
                    "Strength (STR) -\n" +
                    "        Strength increases your carry weight and melee weapon damage. \n" +
                    "Endurance (END) -\n" +
                    "        Endurance is a measure of how tough you are at resisting damage and other ailments. \n" +
                    "Agility (AG) -\n" +
                    "        A higher Agility will make it more likely for you to act before your enemy, dodge, and flee. \n" +
                    "Intelligence (INT) -\n" +
                    "        A higher Intelligence will allow you to accomplish various tasks, such as repairing objects. \n" +
                    "Charisma (CHA) -\n" +
                    "        A higher Charisma will make it easier for you to convince people to do what you want. \n" +
                    "\n" +
                    "You have 70 Skill points to distribute as you see fit amongst your 7 main skills. A skill can not " +
                    "be decreased below the base of 20, nor can it be increase initially above 40. Skills can be increased " +
                    "latter on by leveling up. Chose wisely where you place your points, remember, combat isn't everything!");
            button26.setText("NEXT");
            button26.setVisible(true);
            button21.setText("BACK");
            button21.setVisible(true);
            currentArea = "characterSkills"; //Change area to SKILLS
            return;
        }else{
            enterName.setPromptText("Name must be 1-18 characters long");
            return;
        }
    }

    @FXML
    void button12Pressed(ActionEvent event){
        if(currentArea.equals("characterNaming")&&!enterName.getText().equals("")&&!enterName.getText().equals(" ")&&enterName.getText().length()<18) { //naming -> SKILLS
            //get rid of all the buttons
            resetAllButtons();
            enterName.setVisible(false);
            pointsLeft.setText(""+skillPointsLeft);

            player.setBalSkill(20);
            balSkill.setText(""+player.getBalSkill());
            balSkill2.setText(""+player.getBalSkill());
            player.setWepSkill(20);
            wepSkill.setText(""+player.getWepSkill());
            wepSkill2.setText(""+player.getWepSkill());
            player.setStrSkill(20);
            strSkill.setText(""+player.getStrSkill());
            strSkill2.setText(""+player.getStrSkill());
            player.setEndSkill(20);
            endSkill.setText(""+player.getEndSkill());
            endSkill2.setText(""+player.getEndSkill());
            player.setAgSkill(20);
            agSkill.setText(""+player.getAgSkill());
            agSkill2.setText(""+player.getAgSkill());
            player.setIntSkill(20);
            intSkill.setText(""+player.getIntSkill());
            intSkill2.setText(""+player.getIntSkill());
            player.setChaSkill(20);
            chaSkill.setText(""+player.getChaSkill());
            chaSkill2.setText(""+player.getChaSkill());

            characterSkillIncrease.setVisible(true);
            player.setName(enterName.getText());
            playerName.setText(player.getName());
            player.setGender("female");
            textArea.setText("\n" +
                    "Ballistic Skill (BAL) -\n" +
                    "        A higher Ballistic Skill will make it easier to hit targets at range. \n"+
                    "Weapon Skill (WEP) -\n" +
                    "        A higher Weapon Skill will make it easier to hit targets in melee combat. \n" +
                    "Strength (STR) -\n" +
                    "        Strength increases your carry weight and melee weapon damage. \n" +
                    "Endurance (END) -\n" +
                    "        Endurance is a measure of how tough you are at resisting damage and other ailments. \n" +
                    "Agility (AG) -\n" +
                    "        A higher Agility will make it more likely for you to act before your enemy, dodge, and flee. \n" +
                    "Intelligence (INT) -\n" +
                    "        High Intelligence allows you to accomplish various tasks, such as repairing objects. \n" +
                    "Charisma (CHA) -\n" +
                    "        A higher Charisma will make it easier for you to convince people to do what you want. \n" +
                    "\n" +
                    "You have 70 Skill points to distribute as you see fit amongst your 7 main skills. A skill can not " +
                    "be decreased below the base of 20, nor can it be increase initially above 40. Skills can be increased " +
                    "latter on by leveling up. Chose wisely where you place your points, remember, combat isn't everything!");
            button26.setText("NEXT");
            button26.setVisible(true);
            button21.setText("BACK");
            button21.setVisible(true);
            currentArea = "characterSkills"; //Change area to SKILLS
            return;
        }else{
            enterName.setPromptText("Name must be 1-18 characters long");
            return;
        }
    }

    @FXML
    void button21Pressed(ActionEvent event){
        if(currentArea.equals("characterSkills")) { //skills -> NAMING
            resetAllButtons();
            button11.setText("MALE");
            button11.setVisible(true);
            button12.setText("FEMALE");
            button12.setVisible(true);
            textArea.setText("Welcome to the world of Generic TextGame v0.1!\n" +
                    "This world is an attempt to combine the fantasy genera associated with games such as D&D and Pathfinder, " +
                    "with the gritty combat and skill tests found within games such as Dark Heresy and Rouge Trader.\n" +
                    "I've played many games set in a medieval fantasy, i've played many games with a futuristic setting full" +
                    " of spaceships and aliens, I have yes to find a mixture of both. This game is my perspective as to what" +
                    " a world would be like if that same fantasy genera we're all familiar with was moved to a modern setting. \n\n" +
                    "To begin your adventure, please enter your character name and gender!");
            enterName.setVisible(true);
            characterSkillIncrease.setVisible(false);
            currentArea = "characterNaming"; //Change area to NAMING
            return;
        }
        if(currentArea.equals("characterAppearance")){ //appearance -> SKILLS
            resetAllButtons();
            resetAllChoiceBoxes();
            appearanceMenu.setVisible(false);
            pointsLeft.setText(""+skillPointsLeft);

            textArea.setText("\n" +
                    "Ballistic Skill (BAL) -\n" +
                    "        A higher Ballistic Skill will make it easier to hit targets at range. \n"+
                    "Weapon Skill (WEP) -\n" +
                    "        A higher Weapon Skill will make it easier to hit targets in melee combat. \n" +
                    "Strength (STR) -\n" +
                    "        Strength increases your carry weight and melee weapon damage. \n" +
                    "Endurance (END) -\n" +
                    "        Endurance is a measure of how tough you are at resisting damage and other ailments. \n" +
                    "Agility (AG) -\n" +
                    "        A higher Agility will make it more likely for you to act before your enemy, dodge, and flee. \n" +
                    "Intelligence (INT) -\n" +
                    "        High Intelligence allows you to accomplish various tasks, such as repairing objects. \n" +
                    "Charisma (CHA) -\n" +
                    "        A higher Charisma will make it easier for you to convince people to do what you want. \n" +
                    "\n" +
                    "You have 70 Skill points to distribute as you see fit amongst your 7 main skills. A skill can not " +
                    "be decreased below the base of 20, nor can it be increase initially above 40. Skills can be increased " +
                    "latter on by leveling up. Chose wisely where you place your points, remember, combat isn't everything!");
            button26.setText("NEXT");
            button26.setVisible(true);
            button21.setText("BACK");
            button21.setVisible(true);
            characterSkillIncrease.setVisible(true);
            currentArea = "characterSkills"; //Change area to SKILLS
            return;
        }
    }

    @FXML
    void button26Pressed(ActionEvent event) {
        if (currentArea.equals("characterSkills") && skillPointsLeft == 0) { //skills -> APPEARANCE
            resetAllButtons();
            characterSkillIncrease.setVisible(false);
            player.calculateModifiers();
            player.calculateMaxHealth();
            player.setCurrentHealth(player.getMaxHealth());
            healthNumber.setText("" + player.getCurrentHealth());
            healthBar.setWidth(player.calculateHealthBarPercentage());

            balSkill.setText("" + player.getBalSkill());
            wepSkill.setText("" + player.getWepSkill());
            strSkill.setText("" + player.getStrSkill());
            endSkill.setText("" + player.getEndSkill());
            agSkill.setText("" + player.getAgSkill());
            intSkill.setText("" + player.getIntSkill());
            chaSkill.setText("" + player.getChaSkill());

            button21.setText("BACK");
            button21.setVisible(true);

            button26.setText("NEXT");
            button26.setVisible(true);

            textArea.setText("Here is where you can customize your character. Once all the fields are filled you can " +
                    "continue onto the next page. Select a race to get more information about it.");

            appearanceMenu.setVisible(true);
            if (player.getGender().equals("female")) {
                facialHairOption.setVisible(false);
                String[] bodyFemale = new String[]{"random", "athletic", "beautiful", "big bottomed", "busty", "chubby", "curvy", "cute", "elegant", "flat chested", "graceful", "leggy", "lithe", "petite", "plain", "skinny", "slender", "stunning", "tall", "toned", "tough", "twitchy", "wiry"};
                bodyChoice.clear();
                bodyChoice.addAll(Arrays.asList(bodyFemale));
                bodyChoiceBox.setItems(FXCollections.observableArrayList(bodyChoice));
                hairStyleChoiceBox.setItems(FXCollections.observableArrayList(hairStyleFemale));
            } else {
                facialHairOption.setVisible(true);
                String[] bodyMale = new String[]{"random", "burly", "chubby", "elegant", "gangly", "graceful", "handsome", "husky", "lanky", "lumbering", "muscular", "plain", "potbellied", "runty", "skinny", "slight", "solid", "stocky", "strapping", "tall", "taut", "toned", "wiry"};
                bodyChoice.clear();
                bodyChoice.addAll(Arrays.asList(bodyMale));
                bodyChoiceBox.setItems(FXCollections.observableArrayList(bodyChoice));
                hairStyleChoiceBox.setItems(FXCollections.observableArrayList(hairStyleMale));
            }
            raceChoiceBox.setItems(FXCollections.observableArrayList(races));
            ageChoiceBox.setItems(FXCollections.observableArrayList(age));
            lineageChoiceBox.setItems(FXCollections.observableArrayList(lineage));
            facialHairChoiceBox.setItems(FXCollections.observableArrayList(facialHair));
            raceChoiceBox.valueProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue ov, String oldChoice, String newChoice) {
                    if (newChoice == null) {
                    } else if (newChoice.equals("human")) {
                        textArea.clear();
                        textArea.setText("Humans... they're inferior in every sense of the word. They don't excel in intelligence, strength, nor endurance. Yet what can be said about humanity? They're a self loathing lot, wrapped up in fighting and bickering with each other, one would think such a divided race would crumble faster than a house of cards. Yet all too many have made the grave mistake of underestimating these perplexing creatures, they have this nasty habit of overcoming the impossible when backed into a corner. My advice to you? Leave them be. They'll all kill themselves off sooner or later, I say let them, it's not worth waisting more live to humanities stubborn refusal to die.");
                        complexionChoiceBox.setItems(FXCollections.observableArrayList(humanComplexion));
                        eyeColorChoiceBox.setItems(FXCollections.observableArrayList(humanEyeColor));
                        hairColorChoiceBox.setItems(FXCollections.observableArrayList(humanHairColor));
                    } else if (newChoice.equals("demon")) {
                        textArea.clear();
                        textArea.setText("DEMON DESCRIPTION");
                        complexionChoiceBox.setItems(FXCollections.observableArrayList(demonComplexion));
                        eyeColorChoiceBox.setItems(FXCollections.observableArrayList(demonEyeColor));
                        hairColorChoiceBox.setItems(FXCollections.observableArrayList(demonHairColor));
                    }
                }
            });
            bodyChoiceBox.valueProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue ov, String oldChoice, String newChoice) {
                    if (newChoice == null) {

                    } else if (newChoice == "random") {
                        body2Choice.clear();
                        body2Choice.addAll(bodyChoice);
                        body2ChoiceBox.setItems(FXCollections.observableArrayList(body2Choice));
                    } else {
                        body2Choice.clear();
                        body2Choice.addAll(bodyChoice);
                        body2Choice.remove(newChoice);
                        body2ChoiceBox.setItems(FXCollections.observableArrayList(body2Choice));
                    }
                }
            });
            raceChoiceBox.getSelectionModel().selectFirst();
            ageChoiceBox.getSelectionModel().selectFirst();
            bodyChoiceBox.getSelectionModel().selectFirst();
            body2ChoiceBox.getSelectionModel().selectFirst();
            hairStyleChoiceBox.getSelectionModel().selectFirst();
            hairColorChoiceBox.getSelectionModel().selectFirst();
            eyeColorChoiceBox.getSelectionModel().selectFirst();
            complexionChoiceBox.getSelectionModel().selectFirst();
            lineageChoiceBox.getSelectionModel().selectFirst();
            facialHairChoiceBox.getSelectionModel().selectFirst();
            currentArea = "characterAppearance";
            return;
        }
        if (currentArea.equals("characterAppearance")) {
            if (allChoiceBoxesFull()) {
                Random rand = new Random();
                if (raceChoiceBox.getValue().equals("random")) {
                    int randomNum = rand.nextInt(raceChoiceBox.getItems().size());
                    if (randomNum == 0) {
                        randomNum += 1;
                    }
                    player.setRace(raceChoiceBox.getItems().get(randomNum));
                } else {
                    player.setRace(raceChoiceBox.getValue());
                }

                if (ageChoiceBox.getValue().equals("random")) {
                    int randomNum = rand.nextInt(ageChoiceBox.getItems().size());
                    if (randomNum == 0) {
                        randomNum += 1;
                    }
                    player.setAge(ageChoiceBox.getItems().get(randomNum));
                } else {
                    player.setAge(ageChoiceBox.getValue());
                }

                if (bodyChoiceBox.getValue().equals("random")) {
                    int randomNum = rand.nextInt(bodyChoiceBox.getItems().size());
                    if (randomNum == 0) {
                        randomNum += 1;
                    }
                    player.setBodyTrait(bodyChoiceBox.getItems().get(randomNum));
                } else {
                    player.setBodyTrait(bodyChoiceBox.getValue());
                }
                if (body2ChoiceBox.getValue().equals("random")) {
                    int randomNum = rand.nextInt(body2ChoiceBox.getItems().size());
                    if (randomNum == 0) {
                        randomNum += 1;
                    }
                    player.setBodyTrait2(body2ChoiceBox.getItems().get(randomNum));
                } else {
                    player.setBodyTrait2(body2ChoiceBox.getValue());
                }
                if (hairStyleChoiceBox.getValue().equals("random")) {
                    int randomNum = rand.nextInt(hairStyleChoiceBox.getItems().size());
                    if (randomNum == 0) {
                        randomNum += 1;
                    }
                    player.setHairStyle(hairStyleChoiceBox.getItems().get(randomNum));
                } else {
                    player.setHairStyle(hairStyleChoiceBox.getValue());
                }
                if (hairColorChoiceBox.getValue().equals("random")) {
                    int randomNum = rand.nextInt(hairColorChoiceBox.getItems().size());
                    if (randomNum == 0) {
                        randomNum += 1;
                    }
                    player.setHairColor(hairColorChoiceBox.getItems().get(randomNum));
                } else {
                    player.setHairColor(hairColorChoiceBox.getValue());
                }
                if (eyeColorChoiceBox.getValue().equals("random")) {
                    int randomNum = rand.nextInt(eyeColorChoiceBox.getItems().size());
                    if (randomNum == 0) {
                        randomNum += 1;
                    }
                    player.setEyeColor(eyeColorChoiceBox.getItems().get(randomNum));
                } else {
                    player.setEyeColor(eyeColorChoiceBox.getValue());
                }
                if (complexionChoiceBox.getValue().equals("random")) {
                    int randomNum = rand.nextInt(complexionChoiceBox.getItems().size());
                    if (randomNum == 0) {
                        randomNum += 1;
                    }
                    player.setComplexion(complexionChoiceBox.getItems().get(randomNum));
                } else {
                    player.setComplexion(complexionChoiceBox.getValue());
                }
                if (lineageChoiceBox.getValue().equals("random")) {
                    int randomNum = rand.nextInt(lineageChoiceBox.getItems().size());
                    if (randomNum == 0) {
                        randomNum += 1;
                    }
                    player.setLineage(lineageChoiceBox.getItems().get(randomNum));
                } else {
                    player.setLineage(lineageChoiceBox.getValue());
                }
                if (player.getGender().equals("male")) {
                    if (facialHairChoiceBox.getValue().equals("random")) {
                        int randomNum = rand.nextInt(facialHairChoiceBox.getItems().size());
                        if (randomNum == 0) {
                            randomNum += 1;
                        }
                        player.setFacialHair(facialHairChoiceBox.getItems().get(randomNum));
                    } else {
                        player.setFacialHair(facialHairChoiceBox.getValue());
                    }
                }

                if (player.getRace().equals("demon")) {
                    player.setHasWings(true);
                    player.setWingType("demonic");
                }

                player.setCredits(10 * (player.getChaModifier() * player.getChaModifier()));

                Clothing startingCloths = new Clothing("Plain Clothing", "ragged plain cloths", "Everyday street cloths consisting of jeans, t-shirt, and a worn jacket. The scuffs and scrapes are rather noticeable, a testament to its age.", 20, 1, null);
                RangedWeapon startingPistol = new RangedWeapon("Old .45 Pistol", "a rusty old .45", "An old Mustang .45, although outdated, they're still known for their reliability. It's a miracle this gun fires at all considering it's age and wear.", 50, 1, null, 5, 10, 0, 7, "120");
                MeleeWeapon startingKnife = new MeleeWeapon("Utility Knife", "an old utility knife", "An old utility knife made to accomplish various day to day tasks. Its seen a lot of wear over the years.", 10, 1, null, 5, 8, 1);

//                RangedWeapon testRifle = new RangedWeapon("Test Rifle", "a rifle used for testing", "it tests things", 100, 1, null, 7, 12, 2, 30, "136");
//                player.addItemToInventory(testRifle);

                player.addItemToInventory(startingKnife);
                player.addItemToInventory(startingPistol);
                player.addItemToInventory(startingCloths);
                startingPistol.useItem(player);
                startingKnife.useItem(player);
                startingCloths.useItem(player);
                new PrimarySceneView(Launcher.stage);
                player.setTime("9:35");
                return;
            }
        }
    }

    /**
     * Methods for increasing the players stats
     */
    @FXML
    void balSkillUpPressed(ActionEvent event){
        if(skillPointsLeft>0&&player.getBalSkill()<40){
            player.setBalSkill(player.getBalSkill()+1);
            balSkill2.setText(""+player.getBalSkill());
            skillPointsLeft -= 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }
    @FXML
    void balSkillDownPressed(ActionEvent event){
        if(player.getBalSkill()>20){
            player.setBalSkill(player.getBalSkill()-1);
            balSkill2.setText(""+player.getBalSkill());
            skillPointsLeft += 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }

    @FXML
    void wepSkillUpPressed(ActionEvent event){
        if(skillPointsLeft>0&&player.getWepSkill()<40){
            player.setWepSkill(player.getWepSkill()+1);
            wepSkill2.setText(""+player.getWepSkill());
            skillPointsLeft -= 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }
    @FXML
    void wepSkillDownPressed(ActionEvent event){
        if(player.getWepSkill()>20){
            player.setWepSkill(player.getWepSkill()-1);
            wepSkill2.setText(""+player.getWepSkill());
            skillPointsLeft += 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }

    @FXML
    void strSkillUpPressed(ActionEvent event){
        if(skillPointsLeft>0&&player.getStrSkill()<40){
            player.setStrSkill(player.getStrSkill()+1);
            strSkill2.setText(""+player.getStrSkill());
            skillPointsLeft -= 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }
    @FXML
    void strSkillDownPressed(ActionEvent event){
        if(player.getStrSkill()>20){
            player.setStrSkill(player.getStrSkill()-1);
            strSkill2.setText(""+player.getStrSkill());
            skillPointsLeft += 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }

    @FXML
    void endSkillUpPressed(ActionEvent event){
        if(skillPointsLeft>0&&player.getEndSkill()<40){
            player.setEndSkill(player.getEndSkill()+1);
            endSkill2.setText(""+player.getEndSkill());
            skillPointsLeft -= 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }
    @FXML
    void endSkillDownPressed(ActionEvent event){
        if(player.getEndSkill()>20){
            player.setEndSkill(player.getEndSkill()-1);
            endSkill2.setText(""+player.getEndSkill());
            skillPointsLeft += 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }

    @FXML
    void agSkillUpPressed(ActionEvent event){
        if(skillPointsLeft>0&&player.getAgSkill()<40){
            player.setAgSkill(player.getAgSkill()+1);
            agSkill2.setText(""+player.getAgSkill());
            skillPointsLeft -= 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }
    @FXML
    void agSkillDownPressed(ActionEvent event){
        if(player.getAgSkill()>20){
            player.setAgSkill(player.getAgSkill()-1);
            agSkill2.setText(""+player.getAgSkill());
            skillPointsLeft += 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }

    @FXML
    void intSkillUpPressed(ActionEvent event){
        if(skillPointsLeft>0&&player.getIntSkill()<40){
            player.setIntSkill(player.getIntSkill()+1);
            intSkill2.setText(""+player.getIntSkill());
            skillPointsLeft -= 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }
    @FXML
    void intSkillDownPressed(ActionEvent event){
        if(player.getIntSkill()>20){
            player.setIntSkill(player.getIntSkill()-1);
            intSkill2.setText(""+player.getIntSkill());
            skillPointsLeft += 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }

    @FXML
    void chaSkillUpPressed(ActionEvent event){
        if(skillPointsLeft>0&&player.getChaSkill()<40){
            player.setChaSkill(player.getChaSkill()+1);
            chaSkill2.setText(""+player.getChaSkill());
            skillPointsLeft -= 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }
    @FXML
    void chaSkillDownPressed(ActionEvent event){
        if(player.getChaSkill()>20){
            player.setChaSkill(player.getChaSkill()-1);
            chaSkill2.setText(""+player.getChaSkill());
            skillPointsLeft += 1;
            pointsLeft.setText(""+skillPointsLeft);
        }
    }
}
